/*
  ******************************************************************************
  * @title   	Practica 4 - Ejercicio 1
  * @author  	Luciano M. Smith
  * @brief		Implementación de un MEF para trabajar con anti-rebotes
  * 			por software.
  * @hardware 	Nucleo-F429ZI
  ******************************************************************************
  */

#include "main.h"
#include "API_delay.h"		// modulo con las funciones de delay

// tiempo de verificación de debounce

#define timeDebounce 40

// Creación de enumeracion  de estados

typedef enum {
	button_up,
	button_falling,
	button_down,
	button_raising,
} debounceState_t;


debounceState_t s_button1;	// variable estado actual

// inicio de estructuras de delay debounce

delay_t d_timer;


// carga el estado inicial. No recibe ni devuelve valores.

void debounceFSM_init() {

	s_button1 = button_up;

}

// Lee las entradas, resuelve la lógica de transición de estados y actualiza las salidas. No recibe ni devuelve valores.

void debounceFSM_update() {


	switch (s_button1) {

		case button_up:

			if(BSP_PB_GetState(BUTTON_USER)){

				s_button1 = button_falling;
				delayRead(&d_timer);

			}

		break;

		case button_falling:

			if (delayRead(&d_timer)) {

				if(BSP_PB_GetState(BUTTON_USER)){
					s_button1 = button_down;
					d_timer.running = false;
					buttonPressed();
				} else {
					s_button1 = button_up;
				}

			}

		break;

		case button_down:

			if(!BSP_PB_GetState(BUTTON_USER)){

				s_button1 = button_raising;
				delayRead(&d_timer);

			}

		break;

		case button_raising:

			if (delayRead(&d_timer)) {

				if(!BSP_PB_GetState(BUTTON_USER)){
					s_button1 = button_up;
					d_timer.running = false;
					buttonReleased();

				} else {
					s_button1 = button_down;
				}

			}

		break;

		default:

			BSP_LED_On(LED2); 	// error no encuentra estado

			while (1) {

			}

		break;
	}

}

// inverte el estado del LED1. No recibe ni devuelve valores.

void buttonPressed() {

	BSP_LED_Toggle(LED1);
}

//  inverte el estado del LED1. No recibe ni devuelve valores.

void buttonReleased() {

	BSP_LED_Toggle(LED3);

}

// estructura principal

int main(void)
{

  // inicialización de la capa de abstracción de hardware

  HAL_Init();

  // inicialización de los delays

  delayInit(&d_timer, timeDebounce);

  // inicialización de los leds on-board

  BSP_LED_Init(LED1);

  BSP_LED_Init(LED3);

  // inicialización del boton del usuario

  BSP_PB_Init(BUTTON_USER, BUTTON_MODE_GPIO);

  // inicializacion de estado de antirebote

  debounceFSM_init();

  // bucle infinito

  while (1) {

	  debounceFSM_update();

  }

}



