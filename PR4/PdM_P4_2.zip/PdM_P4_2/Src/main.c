/*
  ******************************************************************************
  * @title   	Practica 4 - Ejercicio 1
  * @author  	Luciano M. Smith
  * @brief		Implementación de un MEF para trabajar con anti-rebotes
  * 			por software.
  * @hardware 	Nucleo-F429ZI
  ******************************************************************************
  */

#include "main.h"
#include "API_delay.h"		// modulo con las funciones de delay
#include "API_debounce.h"

#define freq1 100
#define freq2 500

bool_t freq = true;

// inicio de estructuras de delay

delay_t dled2;


// estructura principal

int main(void)
{
  // inicialización de la capa de abstracción de hardware

  HAL_Init();

    // inicialización de los leds on-board

  BSP_LED_Init(LED2);


  // inicialización del boton del usuario

  BSP_PB_Init(BUTTON_USER, BUTTON_MODE_GPIO);


  debounceFSM_init();

  delayInit(&dled2, freq1);

  // bucle infinito

  while (1) {

	  debounceFSM_update();

	  if (readKey()) {

		  if (freq) {
			  delayWrite(&dled2, freq2);
			  freq = false;
		  } else {
			  delayWrite(&dled2, freq1 );
			  freq = true;
		  }

	  }

	  if (delayRead(&dled2)) {
		  BSP_LED_Toggle(LED2);
	  }


  }

}



